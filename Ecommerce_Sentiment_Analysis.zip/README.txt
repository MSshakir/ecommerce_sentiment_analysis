# Ecommerce Review Sentiment Analysis

## Run in VS Code

1. Open project folder in VS Code
2. Open terminal
3. Run:

pip install -r requirements.txt

4. Then run:

streamlit run app.py

5. Open browser link shown in terminal

## Run in Jupyter Notebook

Recommended to run in VS Code because Streamlit works best there.

But if using Jupyter:
Open terminal and run:

streamlit run app.py
