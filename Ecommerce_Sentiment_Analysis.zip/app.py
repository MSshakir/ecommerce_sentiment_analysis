import streamlit as st
import pandas as pd
import plotly.express as px
from transformers import pipeline

# -------------------------------
# Page Configuration
# -------------------------------
st.set_page_config(
    page_title="Ecommerce Review Sentiment Analysis",
    layout="wide"
)

st.title("Ecommerce Review Sentiment Analysis")

# -------------------------------
# Load Sentiment Model
# -------------------------------
@st.cache_resource
def load_model():
    model = pipeline(
        "sentiment-analysis",
        model="distilbert-base-uncased-finetuned-sst-2-english"
    )
    return model

classifier = load_model()

# -------------------------------
# Sample Dataset
# -------------------------------
data = {
    "review_id": [1, 2, 3, 4, 5],
    "product": [
        "Fitness Tracker",
        "Fitness Tracker",
        "Fitness Tracker",
        "Wireless Earbuds",
        "Smartphone Case"
    ],
    "rating": [5, 4, 2, 3, 5],
    "review_text": [
        "Exceeded my expectations!",
        "Good value for money.",
        "Battery life could be better.",
        "Average product, expected better.",
        "Five stars, very happy with this purchase."
    ]
}

df = pd.DataFrame(data)

# -------------------------------
# Predict Sentiment
# -------------------------------
def predict_sentiment(text):
    result = classifier(text)[0]
    return result["label"]

# Add sentiments to dataset
df["sentiment"] = df["review_text"].apply(predict_sentiment)

# -------------------------------
# User Review Analysis
# -------------------------------
st.subheader("Analyze Your Own Review")

user_review = st.text_area("Enter review")

if st.button("Analyze"):
    if user_review.strip() != "":
        prediction = predict_sentiment(user_review)
        st.success(f"Predicted Sentiment: {prediction}")
    else:
        st.warning("Please enter a review.")

# -------------------------------
# Dataset Analysis
# -------------------------------
st.subheader("Analyze Dataset")

if st.button("Run Analysis"):

    st.subheader("Results")
    st.dataframe(df)

    st.subheader("Distribution")

    sentiment_counts = df["sentiment"].value_counts().reset_index()
    sentiment_counts.columns = ["Sentiment", "Count"]

    fig = px.bar(
        sentiment_counts,
        x="Sentiment",
        y="Count"
    )

    st.plotly_chart(fig, use_container_width=True)
